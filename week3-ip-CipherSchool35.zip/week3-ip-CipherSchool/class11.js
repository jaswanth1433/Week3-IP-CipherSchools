// var
var container =13
console.log(container);

var container="blue";
console.log(container);

var x= 13 , y= 18 , z= 20;
console.log(x,y,z);

var contain;
console.log(contain);


//example
var bgColor="green"
document.querySelector(".up-container").style.backgroundColor= bgColor;
var bgColor="pink";

document.querySelector(".bottom-container").style.backgroundColor= bgColor;
function heading(){
    var bgColor="blue";
    document.querySelector(".heading").style.color=bgColor;
}

heading();
// let



//example
let backgroundColor="green";
document.querySelector(".up-container").style.backgroundColor= backgroundColor;
let sColor="pink";

document.querySelector(".bottom-container").style.backgroundColor= sColor;
function heading(){
    let bgColor="blue";
    document.querySelector(".heading").style.color=bgColor;
}
heading();


//const

//example
const ckgroundColor="green";
document.querySelector(".up-container").style.backgroundColor= backgroundColor;
 backgroundColor="green";

document.querySelector(".bottom-container").style.backgroundColor= sColor;
function heading(){
    let bgColor="blue"
    document.querySelector(".heading").style.color=bgColor;
}
heading();